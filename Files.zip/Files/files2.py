#2. Write a program to write text to .txt file using InputStream

text_to_write = "writing some random text here"

file_path = 'output.txt'
try:
    with open(file_path, 'w') as file:
        file.write(text_to_write)
except Exception as e:
    print(f"An error occurred: {str(e)}")

#3. Write a program to read a file stream
file_path = 'sample.txt'
try:
    with open(file_path, 'rb') as file:
        file_contents = file.read()
        print(f"Read {len(file_contents)} bytes from the file.")
except FileNotFoundError:
    print(f"File not found: {file_path}")
except Exception as e:
    print(f"An error occurred: {str(e)}")

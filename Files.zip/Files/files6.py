'''
6. Write a program to check whether a file is having read access and write access permissions
'''
import os

file_path = 'sample.txt'

# Check if the file exists
if os.path.exists(file_path):
    # Check read access
    if os.access(file_path, os.R_OK):
        print(f"{file_path} has read access.")

    # Check write access
    if os.access(file_path, os.W_OK):
        print(f"{file_path} has write access.")

    # Check execute (execute permissions) access
    if os.access(file_path, os.X_OK):
        print(f"{file_path} has execute access.")
    else:
        print(f"{file_path} does not have execute access.")
else:
    print(f"{file_path} does not exist.")


#5. Write a program to read a file a just to a particular index using seek()

file_path = 'sample.txt'
try:
    with open(file_path, 'rb') as file:
        # Move the file pointer to a specific position
        file.seek(20)

        # Read from the current position to the end of the file
        file_contents = file.read()

        # Print the content
        print(file_contents.decode('utf-8'))  # Assuming the content is text

except FileNotFoundError:
    print(f"File not found: {file_path}")
except Exception as e:
    print(f"An error occurred: {str(e)}")

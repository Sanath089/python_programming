#4. Write a program to read a file stream supports random access

file_path = 'sample.txt'
try:
    with open(file_path, 'rb') as file:
        file.seek(10)
        data = file.read(50)

        print(data.decode('utf-8'))

except FileNotFoundError:
    print(f"File not found: {file_path}")
except Exception as e:
    print(f"An error occurred: {str(e)}")

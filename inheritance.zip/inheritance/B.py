from A import A  # Import the superclass A

class B(A):
    def method_B1(self):
        print("Method B1 in class B")

    def method_B2(self):
        print("Method B2 in class B")

    def overridden_method(self):
        print("Overridden method in class B")
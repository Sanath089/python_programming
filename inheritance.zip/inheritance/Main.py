from A import A
from B import B
from C import C

def main():
    # Create objects for each class
    obj_A = A()
    obj_B = B()
    obj_C = C()

    # Call methods for each class
    obj_A.method_A1()
    obj_A.method_A2()
    obj_A.overridden_method()

    obj_B.method_B1()
    obj_B.method_B2()
    obj_B.overridden_method()

    obj_C.method_C1()
    obj_C.method_C2()
    obj_C.overridden_method()

    # Call overridden method with superclass reference
    super_ref_B = B()
    super_ref_C = C()

    super_ref_B.overridden_method()
    super_ref_C.overridden_method()

if __name__ == "__main__":
    main()

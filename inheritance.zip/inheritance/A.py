class A:
    def method_A1(self):
        print("Method A1 in class A")

    def method_A2(self):
        print("Method A2 in class A")

    def overridden_method(self):
        print("Overridden method in class A")
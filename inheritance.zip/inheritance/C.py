from B import B  # Import the subclass B

class C(B):
    def method_C1(self):
        print("Method C1 in class C")

    def method_C2(self):
        print("Method C2 in class C")

    def overridden_method(self):
        print("Overridden method in class C")

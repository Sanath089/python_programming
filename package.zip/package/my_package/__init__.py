from my_package.class1 import Class1
from my_package.class2 import Class2

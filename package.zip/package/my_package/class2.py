class Class2:
    def __init__(self, name):
        self.name = name

    def greet(self):
        return f"Hi from Class2, {self.name}!"

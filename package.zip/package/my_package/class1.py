class Class1:
    def __init__(self, name):
        self.name = name

    def greet(self):
        return f"Hello from Class1, {self.name}!"

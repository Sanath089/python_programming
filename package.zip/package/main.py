from my_package import Class1, Class2

# Create objects for Class1 and Class2
obj1 = Class1("Alice")
obj2 = Class2("Bob")

# Call the greet method of each class
greeting1 = obj1.greet()
greeting2 = obj2.greet()

# Print the greetings
print(greeting1)
print(greeting2)
